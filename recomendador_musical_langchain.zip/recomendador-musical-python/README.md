# Recomendador Musical com IA Gemini + SQLite

Este projeto usa:
- Python Flask no backend
- API Gemini para gerar recomendações musicais
- SQLite para salvar o histórico das pesquisas

## 1. Instalar dependências

```bash
pip install -r requirements.txt
```

## 2. Configurar Gemini

Crie um arquivo chamado `.env` na pasta do projeto e coloque:

```env
GEMINI_API_KEY=sua_chave_do_gemini_aqui
GEMINI_MODEL=gemini-2.0-flash
PORT=3000
SQLITE_DB=recomendador.db
```

## 3. Rodar o projeto

```bash
python app.py
```

## 4. Testar no navegador

Status do sistema:

http://localhost:3000/api/status

Tela principal:

http://localhost:3000

Histórico salvo no SQLite:

http://localhost:3000/api/historico

## Observação

O arquivo `recomendador.db` é criado automaticamente quando o projeto roda.
As tabelas também são criadas automaticamente.
