const btn = document.getElementById('btnRecomendar');
const statusEl = document.getElementById('status');
const resultadoEl = document.getElementById('resultado');

btn.addEventListener('click', async () => {
  const artistas = document.getElementById('artistas').value.trim();
  const musicas = document.getElementById('musicas').value.trim();

  btn.disabled = true;
  statusEl.textContent = 'Consultando a IA Gemini via Python...';
  resultadoEl.innerHTML = '';

  try {
    const resposta = await fetch('/api/recomendar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ artistas, musicas })
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
      if (dados.fallback) {
        mostrarResultado(dados.fallback);
        statusEl.textContent = 'Gemini falhou, mas o sistema usou o modo offline.';
        return;
      }

      throw new Error(dados.erro || 'Erro desconhecido.');
    }

    mostrarResultado(dados);
    statusEl.textContent = dados.aviso ? 'Gemini falhou, mas o modo offline respondeu.' : 'Recomendações geradas com sucesso.';
  } catch (erro) {
    statusEl.textContent = '';
    resultadoEl.innerHTML = `<p class="erro">${erro.message}</p>`;
  } finally {
    btn.disabled = false;
  }
});

function mostrarResultado(dados) {
  const artistas = dados.artistas_recomendados || [];
  const musicas = dados.musicas_recomendadas || [];

  resultadoEl.innerHTML = `
    <h3>Seu perfil musical</h3>
    <p>${dados.perfil || 'Perfil não informado.'}</p>

    <h3>Artistas semelhantes</h3>
    ${artistas.length ? `<ul>${artistas.map((a) => `<li>${a}</li>`).join('')}</ul>` : '<p>Nenhum artista recomendado.</p>'}

    <h3>Músicas recomendadas</h3>
    ${musicas.length ? musicas.map((m) => `
      <div class="item-musica">
        <strong>${m.musica || 'Música'}</strong> - ${m.artista || 'Artista'}<br>
        <small>${m.motivo || ''}</small>
      </div>
    `).join('') : '<p>Nenhuma música recomendada.</p>'}
  `;
}
