# Recomendador Musical com IA - Versão Python

Projeto em **Python + Flask** que recebe artistas/músicas preferidas e retorna recomendações usando a **Gemini API**.

## Tecnologias

- Python
- Flask
- HTML
- CSS
- JavaScript
- Gemini API

## Como rodar no Windows

### 1. Entrar na pasta do projeto

Abra o CMD na pasta do projeto.

### 2. Criar ambiente virtual

```cmd
python -m venv venv
```

### 3. Ativar o ambiente virtual

```cmd
venv\Scripts\activate
```

### 4. Instalar dependências

```cmd
pip install -r requirements.txt
```

### 5. Criar o arquivo .env

```cmd
copy .env.example .env
notepad .env
```

Dentro do `.env`, coloque sua chave:

```env
GEMINI_API_KEY=sua_chave_gemini_aqui
GEMINI_MODEL=gemini-2.0-flash
PORT=3000
```

### 6. Testar conexão com a API

```cmd
python scripts\test_api.py
```

### 7. Iniciar o sistema

```cmd
python app.py
```

### 8. Abrir no navegador

```txt
http://localhost:3000
```

## Observação

Se a Gemini API falhar, o sistema usa um modo offline de segurança para não quebrar durante a apresentação.
