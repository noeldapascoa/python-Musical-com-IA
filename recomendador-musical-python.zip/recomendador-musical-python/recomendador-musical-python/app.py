import json
import os
import re
from typing import Any, Dict, Optional

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory

load_dotenv()

app = Flask(__name__, static_folder="public", static_url_path="")
PORT = int(os.getenv("PORT", "3000"))
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")


def extrair_json(texto: str) -> Optional[Dict[str, Any]]:
    """Tenta extrair JSON mesmo se a IA devolver markdown ou texto extra."""
    if not texto:
        return None

    limpo = texto.replace("```json", "").replace("```", "").strip()

    try:
        return json.loads(limpo)
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", limpo, flags=re.DOTALL)
    if not match:
        return None

    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None


def fallback_local(artistas: str = "", musicas: str = "") -> Dict[str, Any]:
    texto = f"{artistas} {musicas}".lower()

    bases = [
        {
            "termos": ["eminem", "lose yourself", "rap", "hip hop", "hip-hop"],
            "perfil": "Você curte rap/hip-hop com letras fortes e batidas marcantes.",
            "artistas": ["50 Cent", "Dr. Dre", "Logic", "Joyner Lucas", "NF"],
            "musicas": [
                {"musica": "In Da Club", "artista": "50 Cent", "motivo": "Rap clássico com energia parecida."},
                {"musica": "Forgot About Dre", "artista": "Dr. Dre", "motivo": "Tem ligação direta com o estilo do Eminem."},
                {"musica": "Homicide", "artista": "Logic feat. Eminem", "motivo": "Flow rápido e agressivo."},
            ],
        },
        {
            "termos": ["drake", "travis", "trap", "future"],
            "perfil": "Você curte rap/trap moderno com mistura de melodia e batida forte.",
            "artistas": ["Travis Scott", "Future", "Post Malone", "The Weeknd", "Kanye West"],
            "musicas": [
                {"musica": "SICKO MODE", "artista": "Travis Scott", "motivo": "Trap moderno e popular."},
                {"musica": "Mask Off", "artista": "Future", "motivo": "Batida marcante e vibe parecida."},
                {"musica": "Circles", "artista": "Post Malone", "motivo": "Mistura rap com melodia."},
            ],
        },
        {
            "termos": ["matue", "matuê", "anos luz", "teto", "wiu"],
            "perfil": "Você curte trap nacional com batidas modernas e refrões marcantes.",
            "artistas": ["Teto", "WIU", "Veigh", "Yunk Vino", "Orochi"],
            "musicas": [
                {"musica": "Fim de Semana no Rio", "artista": "Teto", "motivo": "Trap nacional com vibe parecida."},
                {"musica": "Felina", "artista": "WIU", "motivo": "Som moderno e popular no trap BR."},
                {"musica": "Novo Balanço", "artista": "Veigh", "motivo": "Flow e estética próximos."},
            ],
        },
        {
            "termos": ["linkin park", "numb", "rock", "in the end"],
            "perfil": "Você curte rock alternativo/nu metal com refrões fortes.",
            "artistas": ["Evanescence", "Breaking Benjamin", "Three Days Grace", "System of a Down", "Papa Roach"],
            "musicas": [
                {"musica": "Bring Me To Life", "artista": "Evanescence", "motivo": "Rock emocional e marcante."},
                {"musica": "The Diary of Jane", "artista": "Breaking Benjamin", "motivo": "Peso parecido com rock alternativo."},
                {"musica": "Animal I Have Become", "artista": "Three Days Grace", "motivo": "Refrão forte e energia pesada."},
            ],
        },
    ]

    for base in bases:
        if any(termo in texto for termo in base["termos"]):
            return {
                "perfil": f'{base["perfil"]} (modo offline usado como reserva)',
                "artistas_recomendados": base["artistas"],
                "musicas_recomendadas": base["musicas"],
            }

    return {
        "perfil": "Perfil musical variado. Recomendações geradas pelo modo offline de segurança.",
        "artistas_recomendados": ["The Weeknd", "Post Malone", "Imagine Dragons", "Coldplay", "Bruno Mars"],
        "musicas_recomendadas": [
            {"musica": "Blinding Lights", "artista": "The Weeknd", "motivo": "Pop moderno com muita energia."},
            {"musica": "Sunflower", "artista": "Post Malone", "motivo": "Som leve e popular."},
            {"musica": "Believer", "artista": "Imagine Dragons", "motivo": "Refrão forte e fácil de gostar."},
        ],
    }


def consultar_gemini(artistas: str, musicas: str) -> Dict[str, Any]:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()

    if not api_key or "sua_chave" in api_key or "cole" in api_key:
        raise RuntimeError("GEMINI_API_KEY não configurada no arquivo .env")

    prompt = f"""
Você é um recomendador musical. Gere recomendações parecidas com os gostos do usuário.

Artistas informados: {artistas or 'não informado'}
Músicas informadas: {musicas or 'não informado'}

Responda somente em JSON válido, sem markdown, exatamente neste formato:
{{
  "perfil": "texto curto explicando o gosto musical do usuário",
  "artistas_recomendados": ["artista 1", "artista 2", "artista 3", "artista 4", "artista 5"],
  "musicas_recomendadas": [
    {{ "musica": "nome da música", "artista": "nome do artista", "motivo": "motivo curto" }},
    {{ "musica": "nome da música", "artista": "nome do artista", "motivo": "motivo curto" }},
    {{ "musica": "nome da música", "artista": "nome do artista", "motivo": "motivo curto" }}
  ]
}}
""".strip()

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={api_key}"
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.8,
            "maxOutputTokens": 900,
        },
    }

    resposta = requests.post(url, json=payload, timeout=30)

    if resposta.status_code != 200:
        try:
            erro_api = resposta.json()
        except Exception:
            erro_api = resposta.text
        raise RuntimeError(f"Erro Gemini {resposta.status_code}: {erro_api}")

    dados_api = resposta.json()
    texto = (
        dados_api.get("candidates", [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "")
    )

    dados = extrair_json(texto)
    if not dados:
        print("Resposta não JSON do Gemini:", texto)
        return fallback_local(artistas, musicas)

    return {
        "perfil": dados.get("perfil") or "Perfil musical gerado pela IA.",
        "artistas_recomendados": dados.get("artistas_recomendados") if isinstance(dados.get("artistas_recomendados"), list) else [],
        "musicas_recomendadas": dados.get("musicas_recomendadas") if isinstance(dados.get("musicas_recomendadas"), list) else [],
    }


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.post("/api/recomendar")
def recomendar():
    corpo = request.get_json(silent=True) or {}
    artistas = (corpo.get("artistas") or "").strip()
    musicas = (corpo.get("musicas") or "").strip()

    if not artistas and not musicas:
        return jsonify({"erro": "Digite pelo menos um artista ou uma música."}), 400

    try:
        return jsonify(consultar_gemini(artistas, musicas))
    except Exception as erro:
        print("ERRO GEMINI:", erro)
        # Retorna 200 com fallback para o site nunca travar na apresentação.
        fallback = fallback_local(artistas, musicas)
        fallback["aviso"] = f"Gemini falhou, usando modo offline: {erro}"
        return jsonify(fallback), 200


@app.get("/api/status")
def status():
    return jsonify({
        "ok": True,
        "backend": "Python Flask",
        "modelo": GEMINI_MODEL,
        "gemini_key_configurada": bool(os.getenv("GEMINI_API_KEY", "").strip()),
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, debug=True)
